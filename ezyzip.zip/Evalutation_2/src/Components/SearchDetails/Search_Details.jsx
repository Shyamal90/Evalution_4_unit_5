import React from 'react'

function Search_Details() {
  return (
    <div>
      
    </div>
  )
}

export default Search_Details
