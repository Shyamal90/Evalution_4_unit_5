export const GET_DATA = (data) =>{
    // console.log(data);
    return {
        type: "GET_DATA",
        payload: data
    }
}